# Ex 1: SyntaxError
print("Hello CAPP!)
