# 2: NameError
def cube(num):
    return num * num * num


number = 42
print("number = ", number)
print("cubed = ", cube(number))
