# 3: TypeError


def cube(num):
    return num * num * num


word = "nova"
print("word = ", word)
print("cubed? ", cube(word))
